
Date.prototype.getDOY = function() {
	var onejan = new Date(this.getFullYear(),0,1);
	return Math.ceil((this - onejan) / 86400000);
}
var today = new Date();
var daynum = today.getDOY();
var fileName = "brdc"+("00" + daynum).slice(-3)+"0."+today.getFullYear().toString().slice(-2)+"n.Z");


var ftp = require('ftp-get') 
var url = "ftp://cddis.gsfc.nasa.gov/gnss/data/daily/2017/brdc/" + fileName;
 
ftp.get(url, fileName, function (err, res) {
    console.log(err, res);
})